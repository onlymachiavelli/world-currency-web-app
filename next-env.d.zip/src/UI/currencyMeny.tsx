import Reac, {} from 'react'

const currencyMenu = ({...props}) =>{

    return (
        <div className={``}>

        </div>
    )
}



export default currencyMenu